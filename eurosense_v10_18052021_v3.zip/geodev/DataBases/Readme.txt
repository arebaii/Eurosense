- Documentation BD : Un document qui défini la structure de la base de données, comment la réstaurer et comment créer une connexion entre la BD et le serveur Local Apache (XAMPP)

- "1-backup" : il contient le backup de la base de données (structure et données). 
  Pour la restaurer il suffit de suivre le guide de restauration dans la partie de Base de donnée de la documentation 

- "2- SQL - tables et functions" : Il contient les requettes SQL de la crétion des tables et les fonctions d'automatisation mentionnées dans la documentation

