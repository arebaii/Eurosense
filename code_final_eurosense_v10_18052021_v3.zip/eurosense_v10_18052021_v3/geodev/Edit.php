<div id=E-id><p>
<?php //Fenétre de selection de la mission à éditer:
echo "Editer la mission d'id :";
?>
</p></div>